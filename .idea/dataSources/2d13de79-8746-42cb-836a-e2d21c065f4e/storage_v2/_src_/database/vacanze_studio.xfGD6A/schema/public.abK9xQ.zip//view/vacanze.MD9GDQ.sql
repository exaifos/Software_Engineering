create view vacanze(data_partenza, città, lingua, durata, id) as
SELECT DISTINCT vacanza_college.data_partenza,
                vacanza_college."città",
                vacanza_college.lingua,
                vacanza_college.durata,
                vacanza_college.id_inserimento AS id
FROM vacanza_college;

alter table vacanze
    owner to postgres;

